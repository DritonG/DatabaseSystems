Usage: java -jar LRUk.jar <k:optional>
k=2, if k is not given via arguments.

Examples:
java -jar LRUk.jar
java -jar LRUk.jar 1
java -jar LRUk.jar 2
