import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;

/**
 * Create initial runs using replacement selection.
 */
public class ReplacementSort
{
    private static int fileNumber = 0;
	
    /**
     * Create a new run file
     */
    private static PrintStream createNewRun()
    {
	StringBuffer fileName = new StringBuffer();
	String name = "run";
	int passNumber = 0;
		
	PrintStream newRun = null;
		
	// file name of the new run file.
	fileName.append(name).append("_").append(passNumber).
	    append("_").append(fileNumber);
		
	try {
	    newRun = new PrintStream (
				      new BufferedOutputStream (
								new FileOutputStream(fileName.toString())));
	} catch(FileNotFoundException fne) {
	    System.err.println(fne.toString());
	    System.exit(1);
	}
		
	fileNumber++;
		
	return newRun;
    }
	
	
    /**
     * This method implements the actual replacement sort algorithm
     * @param file The input file that is to be sorted.
     * @param bufferSize The size of the sorting buffer (number of tuples in
     * current set)
     */
    public static void createPass0(BufferedReader file, int bufferSize)
	throws IOException
    {
    	// IMPLEMENT ME!!!
    }
}
